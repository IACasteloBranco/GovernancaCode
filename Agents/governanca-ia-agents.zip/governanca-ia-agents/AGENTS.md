# AGENTS.md — Governança de IA

## 1. Objetivo

Este repositório é operado por dois agentes com responsabilidades separadas:

- **Codex — Development Agent**: implementa e mantém a extensão de Governança de IA.
- **Work — QA & Red Team Agent**: valida a extensão em navegador real, registra evidências, executa regressão e tenta contornar os controles de forma controlada.

O princípio central é **separação de funções**: quem desenvolve não aprova sozinho a própria implementação.

---

## 2. Fonte de verdade

A ordem de precedência é:

1. Políticas aprovadas pela empresa em `/policies`
2. Casos de teste aprovados em `/qa`
3. Este `AGENTS.md`
4. Documentação técnica em `/docs`
5. Implementação em `/extension`

Nenhum agente pode alterar uma regra de governança apenas para fazer um teste passar.

Se houver conflito entre implementação e política, a política prevalece.

---

## 3. Estrutura esperada

```text
governanca-ia-extension/
├── extension/
├── policies/
├── tests/
├── qa/
├── reports/
├── docs/
├── agents/
│   ├── codex.md
│   └── work-qa.md
└── AGENTS.md
```

### Responsabilidade por diretório

**Codex**
- `/extension`
- `/tests`
- suporte técnico em `/docs`

**Work**
- `/qa`
- `/reports`
- evidências de execução em `/reports/evidence`

**Compartilhado / controlado**
- `/policies`

Alterações em `/policies` exigem aprovação humana explícita.

---

## 4. Regras gerais

### 4.1 Não inventar política

Os agentes não devem decidir autonomamente:
- quais dados são proibidos;
- qual nível de risco deve ser atribuído;
- quando uma exceção deve ser criada;
- quando um bloqueio deve ser removido.

Caso a política seja ambígua, registrar como **POLICY-QUESTION** e solicitar decisão humana.

### 4.2 Evidência obrigatória

Todo bug aberto pelo QA deve conter, quando aplicável:

- ID do teste;
- versão da extensão;
- site testado;
- entrada utilizada;
- resultado esperado;
- resultado observado;
- status;
- severidade;
- passos para reprodução;
- evidência;
- hipótese opcional de causa.

### 4.3 Dados reais

Não usar CPF, senha, token, credencial, chave de API ou outro dado real em testes.

Usar apenas massas sintéticas ou valores explicitamente destinados a teste.

### 4.4 Segurança

Não executar ações destrutivas, excluir dados, enviar credenciais reais ou tentar acessar recursos fora do escopo autorizado.

Red Team significa testar resistência dos controles dentro do ambiente autorizado, não atacar sistemas externos.

---

## 5. Estados de teste

Todo caso deve terminar com um destes estados:

- `PASS`
- `FAIL`
- `BLOCKED`
- `NOT_TESTED`
- `POLICY_QUESTION`

---

## 6. Severidade de bugs

### CRITICAL
O controle falha e permite exposição clara de informação que deveria ser bloqueada, ou a extensão interrompe completamente o fluxo principal.

### HIGH
Falha relevante de bloqueio, captura, classificação, registro ou aplicação da política.

### MEDIUM
Comportamento incorreto com impacto limitado ou contornável.

### LOW
Problema visual, textual ou de usabilidade sem impacto material no controle.

---

## 7. Contrato Work → Codex

Quando o Work encontrar uma falha, deve produzir um bug estruturado.

Formato:

```text
BUG-ID:
TEST-ID:
EXTENSION-VERSION:
SITE:
CATEGORY:
SEVERITY:

INPUT:
EXPECTED:
OBSERVED:

REPRODUCTION:
1.
2.
3.

EVIDENCE:

NOTES:
```

O Work não deve corrigir o código.

---

## 8. Contrato Codex → Work

Quando o Codex corrigir uma falha, deve informar:

```text
BUG-ID:
STATUS: READY_FOR_RETEST
CHANGE-SUMMARY:
FILES-CHANGED:
TESTS-ADDED:
RISKS:
RETEST-INSTRUCTIONS:
```

O Codex não deve marcar o bug como aprovado.

A aprovação final pertence ao Work ou ao responsável humano.

---

## 9. Fluxo de trabalho

```text
Política aprovada
      ↓
Codex implementa
      ↓
Codex executa testes automatizados
      ↓
Build/versão testável
      ↓
Work instala/carrega a extensão
      ↓
Work executa QA funcional
      ↓
Work executa QA de política
      ↓
Work executa Red Team controlado
      ↓
PASS ───────────────→ relatório de aprovação
FAIL
  ↓
bug estruturado
  ↓
Codex corrige
  ↓
READY_FOR_RETEST
  ↓
Work retesta
```

---

## 10. Critério de conclusão

Uma versão só deve ser considerada validada quando:

- testes críticos definidos para a versão foram executados;
- não existem falhas CRITICAL abertas;
- falhas HIGH estão resolvidas ou formalmente aceitas;
- casos de regressão relevantes passaram;
- relatório de QA foi gerado;
- versão testada está identificada.

---

## 11. Princípio de governança

A extensão é um mecanismo de aplicação de política, não a própria política.

Desenvolvimento, teste e decisão de governança devem permanecer separados.
